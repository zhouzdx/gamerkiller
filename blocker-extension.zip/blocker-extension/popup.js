// ===== UTILS =====

async function sha256(str) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

let toastTimer = null;
function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast show' + (type ? ' ' + type : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.className = 'toast'; }, 2200);
}

function normalizeDomain(raw) {
  let s = raw.trim().toLowerCase();
  s = s.replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];
  return s;
}

function isValidDomain(domain) {
  return /^[a-z0-9]([a-z0-9\-\.]*[a-z0-9])?(\.[a-z]{2,})+$/.test(domain);
}

// ===== PASSWORD STRENGTH =====
document.getElementById('setupPw1').addEventListener('input', function () {
  const v = this.value;
  let score = 0;
  if (v.length >= 4) score++;
  if (v.length >= 8) score++;
  if (/[A-Z]/.test(v) || /[0-9]/.test(v)) score++;
  if (/[^A-Za-z0-9]/.test(v)) score++;
  const colors = ['#ef4444', '#f97316', '#eab308', '#16a34a'];
  for (let i = 1; i <= 4; i++) {
    const bar = document.getElementById('s' + i);
    bar.style.background = i <= score ? colors[score - 1] : '#2e2e4a';
  }
});

// ===== SETUP SCREEN =====
document.getElementById('setupBtn').addEventListener('click', async () => {
  const p1 = document.getElementById('setupPw1').value;
  const p2 = document.getElementById('setupPw2').value;

  if (p1.length < 4) {
    document.getElementById('setupPw1').classList.add('error');
    setTimeout(() => document.getElementById('setupPw1').classList.remove('error'), 600);
    showToast('密码至少需要4位', 'error'); return;
  }
  if (p1 !== p2) {
    document.getElementById('setupPw2').classList.add('error');
    setTimeout(() => document.getElementById('setupPw2').classList.remove('error'), 600);
    showToast('两次输入的密码不一致', 'error'); return;
  }

  const hash = await sha256(p1);
  chrome.storage.local.set({ passwordHash: hash, loginAttempts: 0 }, () => {
    showScreen('mainScreen');
    loadSites();
    showToast('✓ 密码设置成功，已解锁', 'success');
  });
});

['setupPw1', 'setupPw2'].forEach(id => {
  document.getElementById(id).addEventListener('keydown', e => {
    if (e.key === 'Enter') document.getElementById('setupBtn').click();
  });
});

// ===== LOGIN SCREEN =====
let loginLocked = false;

document.getElementById('loginBtn').addEventListener('click', async () => {
  if (loginLocked) return;

  const pw = document.getElementById('loginPw').value;
  const input = document.getElementById('loginPw');
  const hintEl = document.getElementById('attemptHint');

  const { passwordHash, loginAttempts } = await chrome.storage.local.get(['passwordHash', 'loginAttempts']);
  const attempts = loginAttempts || 0;

  // Too many attempts: lock for 30s
  if (attempts >= 5) {
    hintEl.textContent = '尝试次数过多，请30秒后再试';
    hintEl.style.color = '#ef4444';
    loginLocked = true;
    let remaining = 30;
    const timer = setInterval(() => {
      remaining--;
      hintEl.textContent = `尝试次数过多，请${remaining}秒后再试`;
      if (remaining <= 0) {
        clearInterval(timer);
        loginLocked = false;
        chrome.storage.local.set({ loginAttempts: 0 });
        hintEl.textContent = '';
        hintEl.style.color = '';
      }
    }, 1000);
    return;
  }

  const hash = await sha256(pw);
  if (hash === passwordHash) {
    chrome.storage.local.set({ loginAttempts: 0 });
    document.getElementById('loginPw').value = '';
    hintEl.textContent = '';
    showScreen('mainScreen');
    loadSites();
  } else {
    const newAttempts = attempts + 1;
    chrome.storage.local.set({ loginAttempts: newAttempts });
    input.classList.add('error');
    setTimeout(() => input.classList.remove('error'), 600);
    input.value = '';
    const left = 5 - newAttempts;
    if (left > 0) {
      hintEl.textContent = `密码错误，还剩 ${left} 次机会`;
      hintEl.style.color = '#f97316';
    } else {
      hintEl.textContent = '尝试次数过多，请30秒后再试';
      hintEl.style.color = '#ef4444';
    }
    showToast('密码错误', 'error');
  }
});

document.getElementById('loginPw').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('loginBtn').click();
});

// ===== LOCK BUTTON =====
document.getElementById('lockBtn').addEventListener('click', () => {
  document.getElementById('loginPw').value = '';
  document.getElementById('attemptHint').textContent = '';
  showScreen('loginScreen');
  document.getElementById('loginPw').focus();
});

// ===== MAIN APP =====
function renderList(sites) {
  const siteList = document.getElementById('siteList');
  const countBadge = document.getElementById('countBadge');
  countBadge.textContent = sites.length + ' 个';

  if (sites.length === 0) {
    siteList.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🛡️</div>
        <p>还没有添加任何拦截网站<br>输入网址开始保护</p>
      </div>`;
    return;
  }

  siteList.innerHTML = '';
  sites.forEach((site, idx) => {
    const item = document.createElement('div');
    item.className = 'site-item';
    item.innerHTML = `
      <div class="site-dot"></div>
      <span class="site-name" title="${site}">${site}</span>
      <button class="remove-btn" data-idx="${idx}" title="移除">✕</button>
    `;
    siteList.appendChild(item);
  });

  siteList.querySelectorAll('.remove-btn').forEach(btn => {
    btn.addEventListener('click', () => removeSite(parseInt(btn.dataset.idx)));
  });
}

function loadSites() {
  chrome.storage.local.get('blockedSites', result => {
    renderList(result.blockedSites || []);
  });
}

function addSite() {
  const siteInput = document.getElementById('siteInput');
  const raw = siteInput.value;
  if (!raw.trim()) return;

  const domain = normalizeDomain(raw);
  if (!isValidDomain(domain)) {
    showToast('请输入有效的域名格式', 'error'); return;
  }

  chrome.storage.local.get('blockedSites', result => {
    const sites = result.blockedSites || [];
    if (sites.includes(domain)) { showToast('该网站已在拦截列表中', 'error'); return; }
    sites.unshift(domain);
    chrome.storage.local.set({ blockedSites: sites }, () => {
      siteInput.value = '';
      renderList(sites);
      showToast('✓ 已添加 ' + domain, 'success');
    });
  });
}

function removeSite(idx) {
  chrome.storage.local.get('blockedSites', result => {
    const sites = result.blockedSites || [];
    const removed = sites.splice(idx, 1)[0];
    chrome.storage.local.set({ blockedSites: sites }, () => {
      renderList(sites);
      showToast('已移除 ' + removed);
    });
  });
}

document.getElementById('addBtn').addEventListener('click', addSite);
document.getElementById('siteInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') addSite();
});

// ===== INIT: decide which screen to show =====
chrome.storage.local.get(['passwordHash'], result => {
  if (!result.passwordHash) {
    showScreen('setupScreen');
    document.getElementById('setupPw1').focus();
  } else {
    showScreen('loginScreen');
    document.getElementById('loginPw').focus();
  }
});
