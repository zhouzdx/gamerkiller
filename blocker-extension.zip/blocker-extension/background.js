// Background service worker for site blocker

// Listen for web navigation to intercept blocked sites
chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0) return; // Only main frame

  const { blockedSites } = await chrome.storage.local.get('blockedSites');
  if (!blockedSites || blockedSites.length === 0) return;

  try {
    const url = new URL(details.url);
    const hostname = url.hostname.replace(/^www\./, '');

    const isBlocked = blockedSites.some(site => {
      const cleanSite = site.replace(/^www\./, '').toLowerCase().trim();
      return hostname.toLowerCase() === cleanSite ||
             hostname.toLowerCase().endsWith('.' + cleanSite);
    });

    if (isBlocked) {
      const blockedUrl = chrome.runtime.getURL('blocked.html') +
        '?site=' + encodeURIComponent(url.hostname);
      chrome.tabs.update(details.tabId, { url: blockedUrl });
    }
  } catch (e) {
    // Invalid URL, ignore
  }
});

// Initialize storage on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get('blockedSites', (result) => {
    if (!result.blockedSites) {
      chrome.storage.local.set({ blockedSites: [] });
    }
  });
});
